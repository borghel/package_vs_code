# gestion_utilisateurs/__init__.py

# Vous pouvez définir des métadonnées ici
__version__ = "1.0.0"
__author__ = "Votre Nom"
